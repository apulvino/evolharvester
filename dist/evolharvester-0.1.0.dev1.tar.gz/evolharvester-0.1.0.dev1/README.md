# evolharvester

[![Tests](https://github.com/apulvino/evolharvester/actions/workflows/tests.yml/badge.svg)](https://github.com/apulvino/evolharvester/actions/workflows/tests.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Python](https://img.shields.io/badge/python-≥3.10-blue.svg)](https://www.python.org/)
[![PyPI](https://img.shields.io/pypi/v/evolharvester.svg)](https://pypi.org/project/evolharvester/)
[![DOI](https://zenodo.org/badge/DOI/PLACEHOLDER.svg)](https://doi.org/PLACEHOLDER)

evolharvester is a command-line utility for parsing HyPhy and PAML codon-selection analysis outputs. It reformats JSONs and report text files into standardized, tidy CSV files for downstream analysis in the user's preferred development environment.

evolharvester takes native HyPhy JSONs and PAML report files source-agnostically (e.g. Datamonkey, local pipelines, archived results, etc).

Results are exported as long-format CSVs with the goal of capturing multi-resolution results per output CSV (e.g. sequence-/branch-keyed rows and vectorized codon-/site-level columns).
